package com.example.lukas.tesonettest

/**
 * Created by lukas on 17.8.17.
 */
class GlobalErrorEvent(val error: String?)
class UnauthorizedEvent