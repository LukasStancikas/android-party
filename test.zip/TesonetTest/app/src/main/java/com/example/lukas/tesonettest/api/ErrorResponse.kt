package com.example.lukas.tesonettest.api

/**
 * Created by lukas on 17.8.17.
 */
class ErrorResponse(val message: String)